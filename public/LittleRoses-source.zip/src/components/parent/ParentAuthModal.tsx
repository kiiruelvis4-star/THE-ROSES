import React, { useState } from 'react';
import { 
  X, 
  GraduationCap, 
  Search, 
  ArrowRight, 
  UserCheck, 
  ShieldCheck, 
  Smartphone, 
  Download,
  CheckCircle2,
  Sparkles,
  Key
} from 'lucide-react';
import { Student } from '../../types';

interface ParentAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  onSelectStudent: (student: Student) => void;
}

export const ParentAuthModal: React.FC<ParentAuthModalProps> = ({
  isOpen,
  onClose,
  students,
  onSelectStudent
}) => {
  const [admInput, setAdmInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleAdmSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const cleanInput = admInput.trim().toUpperCase();
    if (!cleanInput) {
      setErrorMessage('Please enter the learner admission number.');
      return;
    }

    const found = students.find(s => 
      s.admissionNumber.toUpperCase().trim() === cleanInput ||
      s.id.toUpperCase().trim() === cleanInput ||
      cleanInput.includes(s.admissionNumber.toUpperCase().trim())
    );

    if (found) {
      onSelectStudent(found);
      onClose();
    } else {
      setErrorMessage(`No learner found with Admission No. "${cleanInput}". Please check the number or pick from the list below.`);
    }
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.grade.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="p-6 bg-gradient-to-br from-rose-900 via-rose-800 to-rose-950 text-white relative overflow-hidden">
          <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-white/10 blur-xl pointer-events-none" />
          
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center text-white shadow-inner">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black font-heading tracking-tight">
                  Parent & Learner Portal
                </h2>
                <p className="text-xs text-rose-200">
                  Little Roses Academy • Access your learner's portfolio
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-rose-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Sign In By Admission Number Form */}
          <form onSubmit={handleAdmSubmit} className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              Enter Learner Unique Admission Number
            </label>
            <div className="relative">
              <input
                type="text"
                value={admInput}
                onChange={(e) => {
                  setAdmInput(e.target.value);
                  setErrorMessage('');
                }}
                placeholder="e.g. LRA-2021-084 or LRA-2021-091"
                className="w-full pl-4 pr-28 py-3 text-sm font-mono rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-600 outline-hidden transition-all"
              />
              <button
                type="submit"
                className="absolute right-1.5 top-1.5 bottom-1.5 px-4 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5"
              >
                <span>Sign In</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {errorMessage && (
              <p className="text-xs text-rose-600 dark:text-rose-400 font-semibold">
                {errorMessage}
              </p>
            )}
          </form>

          {/* Quick Demo Pickers */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Quick Sample Accounts
              </span>
              <span className="text-[10px] text-slate-400">Click to enter</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {students.slice(0, 4).map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    onSelectStudent(s);
                    onClose();
                  }}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-rose-300 dark:hover:border-rose-800 text-left transition-all group"
                >
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-rose-600 dark:group-hover:text-rose-400">
                    {s.name}
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono">
                    {s.admissionNumber} • {s.grade}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Searchable Learners List */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="relative mb-3">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by learner name, grade or adm no..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-600 outline-hidden"
              />
            </div>

            <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800">
              {filteredStudents.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500">
                  No matching learner found
                </div>
              ) : (
                filteredStudents.slice(0, 8).map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onSelectStudent(s);
                      onClose();
                    }}
                    className="p-3 flex items-center justify-between hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 font-bold text-xs flex items-center justify-center">
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          {s.name}
                        </p>
                        <p className="text-[10px] text-slate-500 font-mono">
                          Adm: {s.admissionNumber} • {s.grade}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-rose-700 dark:text-rose-400 flex items-center gap-1">
                      Enter
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Download for Parents Helper Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-50 to-amber-50 dark:from-rose-950/40 dark:to-amber-950/40 border border-rose-200/60 dark:border-rose-800/40 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Smartphone className="w-5 h-5 text-rose-700 dark:text-rose-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">
                  Install / Download App on Mobile
                </p>
                <p className="text-[10px] text-slate-500">
                  Parents can add this app to their Android or iPhone home screen
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                alert("To install Little Roses Academy on your phone:\n1. On Android Chrome: Tap the 3 dots menu and choose 'Install App' or 'Add to Home Screen'.\n2. On iPhone Safari: Tap the Share button and tap 'Add to Home Screen'.");
              }}
              className="px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-[11px] font-bold shrink-0 transition-all"
            >
              How to Install
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
